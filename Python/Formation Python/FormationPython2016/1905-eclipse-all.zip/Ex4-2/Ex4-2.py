"""
Exercise 4.2 Lambda Functions and Generators
"""
# Part A

Paris = 25
Honolulu = 81

# Create lambda functions below


# Part B

caribList = [ 'GCM', 'CUR' ]
cityList = [ 'HNL', 'CDG', 'MSY', 'CUR', 'HKG', 'YYZ', 'ARN', 'GPT' ]

# Create lambda function below


# Part C

# Create generator function below

# Part D

cityCodeDict = {
    'HNL':'Honolulu',
    'ITO':'Hilo',
    'LHR':'London/Heathrow',
    'ARN':'Stockholm/Arlanda',
    'HKG':'Hong Kong',
    'YYZ':'Toronto',
    'CDG':'Paris/Charles De Gaulle',
    'NRT':'Tokyo/Narita',
    'GCM':'Grand Cayman BWI',
    'CUR':'Curacao Netherland Antilles' }

cityList = [ 'HNL', 'CDG', 'MSY', 'CUR', 'HKG', 'YYZ', 'ARN', 'GPT' ]


# Part E

hawaiiList = [ 'ITO', 'HNL' ]
euroList =  [ 'LHR', 'CDG' ] 
asiaList = [ 'HKG', 'NRT' ]

