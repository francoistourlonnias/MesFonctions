"""
A simple module
"""
print 'starting mod1'
name = 'Python'

def printPython(count = 1):
    print 'Python' * count
    
