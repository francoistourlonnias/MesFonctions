"""
printdemo module
"""
def demo():
    print 'Do the work'