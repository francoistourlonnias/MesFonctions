"""
Another simple module
"""
print 'starting mod2'
import mod1

def printName():
    print mod1.name, 'in mod 2'

    
