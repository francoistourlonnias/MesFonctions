import mod1, mod2

mod1.printPython()
mod2.printName()