import sys

print 'arg count is', len(sys.argv)
for word in sys.argv:
    print 'found', word
