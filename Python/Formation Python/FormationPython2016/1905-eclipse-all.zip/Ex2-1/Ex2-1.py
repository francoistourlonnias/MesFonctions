"""
Exercise 2.1 Simple Arithmetic.
"""

# Part A
ans = '5 / 9'
print 'ans =', ans


# Part B
# ctof = 9 / 5
# ftoc = 5 / 9
# freezing = 32

Paris = '25'
Honolulu = '81'


# part C
price = '199.95'

discountA = .05
discountB = .10
discountC = .15



# Part D

