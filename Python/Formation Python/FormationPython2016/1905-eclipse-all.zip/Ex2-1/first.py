# -*- encoding: utf-8 -*-
print 'Bonjour à vous'
# Ceci est un commentaire