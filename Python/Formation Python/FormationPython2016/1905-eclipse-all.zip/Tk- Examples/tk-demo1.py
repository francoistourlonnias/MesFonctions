"""
tk-demo1.py
"""

from Tkinter import *

lab1 = Label(None, text='I am a label')
btn1 = Button(None, text='I am a button')

mainloop()


