    

print "Content-type: text/html"



print """

<html>

   <body>
      <h1>Today's date is 
"""        


print """    

    </h1>
   
   </body>


</html>

"""
