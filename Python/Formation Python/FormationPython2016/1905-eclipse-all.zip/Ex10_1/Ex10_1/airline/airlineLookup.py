'''
airlineLoopup.py
'''

import sqlModule
import airlineClasses

cityCodeDict = sqlModule.getCityCodeDict()
reservationDict = sqlModule.getReservationDict()
# dictionaries are built from the database

def findCity(cityCode):
# add cityCodeDict dictionary lookup below
# return a dictionary to the view method, key is the parameter, value is associated value 
# for that key, else an error message string
    pass

