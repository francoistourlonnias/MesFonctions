/*
 * ConcessionException.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include <ConcessionException.hpp>
#include <string>

using namespace std;

ConcessionException::ConcessionException(string errorMessage):
m_errorMessage(errorMessage){
	// TODO Auto-generated constructor stub

}

ConcessionException::~ConcessionException() {
	// TODO Auto-generated destructor stub
}

