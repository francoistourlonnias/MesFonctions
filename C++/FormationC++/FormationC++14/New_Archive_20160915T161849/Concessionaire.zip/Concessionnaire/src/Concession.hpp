/*
 * Concession.hpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_CONCESSION_HPP_
#define SRC_CONCESSION_HPP_

#include <string>
#include <vector>
#include "Vehicule.hpp"
#include <memory>

class Concession {
public:
	Concession();
	Concession(int tresorerieInitiale);
	virtual ~Concession();
	void ajouterNouveauVehicule(std::unique_ptr<Vehicule> pNouveauVehicule);
	std::string inventaire();
	int calculerValeurStock();
	int getTresorerie();
	void updateTresorerie(int updateValue);
	void vendreVehicule(int indexVehicule);
	bool isVehiculeIndexWithinRange(int indexVehicule);
	void acheter(std::unique_ptr<Vehicule> pNouveauVehicule);
	double getMarge();
	int nombreVehicules(const char* vehicleType);
	void removeVehicle(int indexVehiculeToDelete);
	void reduction(int pourcentage);
	void augmentation(int pourcentage);
	void liquidationMarque(std::string marque);

private:
	void applicationPourcentage(int pourcentage);
	std::vector<std::unique_ptr<Vehicule>> m_tableauPointerVehicules;
	std::string  m_nom;
	int m_tresorerie;
	double m_margin;
};

#endif /* SRC_CONCESSION_HPP_ */
