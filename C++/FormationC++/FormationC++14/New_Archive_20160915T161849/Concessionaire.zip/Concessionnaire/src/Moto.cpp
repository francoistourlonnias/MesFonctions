/*
 * Moto.cpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#include <Moto.hpp>
#include <Vehicule.hpp>
#include <string>
using namespace std;

Moto::Moto(string m_marque, string m_modele, string m_couleur, int m_prix, int cylindree) :
Vehicule(m_marque, m_modele, m_couleur, m_prix), m_cylindree(cylindree){
	// TODO Auto-generated constructor stub

}

Moto::~Moto() {
	// TODO Auto-generated destructor stub
}

string Moto::description(){
	string maDescription("");

	maDescription+=Vehicule::description()+" Cylindree: "+to_string(m_cylindree);
	return maDescription;
}
