/*
 * Vehicule.cpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#include <Vehicule.hpp>
#include <string>
#include <iostream>
using namespace std;

Vehicule::Vehicule(string marque, string modele, string couleur, int prix):
m_marque(marque), m_modele(modele), m_couleur(couleur), m_prix(prix)
{

}


Vehicule::~Vehicule() {
}

string Vehicule::description(){
	string maDescription("");
	maDescription += "Marque: "+ getMarque() + " Modele: " + m_modele +" Couleur: " + m_couleur + " Prix: " + to_string(getPrice());

	return maDescription;
}

void Vehicule::modifierPrix(int nouveauPrix)
{
	m_prix = nouveauPrix;
}

string Vehicule::getMarque(){
	return m_marque;
}

int Vehicule::getPrice(){
	return m_prix;
}
