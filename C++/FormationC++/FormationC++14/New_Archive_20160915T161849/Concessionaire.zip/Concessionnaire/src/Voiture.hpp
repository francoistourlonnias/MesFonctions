/*
 * Voiture.hpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_VOITURE_HPP_
#define SRC_VOITURE_HPP_
#include <string>
#include <Vehicule.hpp>

class Voiture : public Vehicule {
public:
	Voiture(std::string marque, std::string modele, std::string couleur,std::string type, int prix);
	virtual ~Voiture();
	std::string description() override;
private:
	std::string m_type;
};

#endif /* SRC_VOITURE_HPP_ */
