/*
 * Vehicule.hpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_VEHICULE_HPP_
#define SRC_VEHICULE_HPP_

#include <string>

class Vehicule {
public:
	Vehicule(){m_marque="",m_modele="",m_couleur="",m_prix=0;};
	Vehicule(std::string m_marque, std::string m_modele, std::string m_couleur, int m_prix);
	virtual ~Vehicule();
	void modifierPrix(int nouveauPrix);
	virtual std::string description();
	std::string getMarque();
	int getPrice();

private:
	std::string m_marque, m_modele, m_couleur;
	int m_prix;
};

#endif /* SRC_VEHICULE_HPP_ */
