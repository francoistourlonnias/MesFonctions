/*
 * ConcessionException.h
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_CONCESSIONEXCEPTION_HPP_
#define SRC_CONCESSIONEXCEPTION_HPP_

#include <exception>
#include <string>


class ConcessionException : public std::exception {
public:
	ConcessionException(std::string errorMessage);
	virtual ~ConcessionException();

	virtual const char* what() const throw(){
		return m_errorMessage.c_str();
	}
private:
	std::string m_errorMessage;
};

#endif /* SRC_CONCESSIONEXCEPTION_HPP_ */
