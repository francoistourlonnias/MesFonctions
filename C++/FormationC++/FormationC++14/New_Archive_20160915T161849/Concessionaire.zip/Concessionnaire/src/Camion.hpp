/*
 * Camion.hpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_CAMION_HPP_
#define SRC_CAMION_HPP_
#include "Vehicule.hpp"
#include <string>

class Camion : public Vehicule{
public:
	Camion(std::string m_marque, std::string m_modele, std::string m_couleur, int m_prix, int ptac);
	virtual ~Camion();
	std::string description() override;

private:
	int m_PTAC;
};

#endif /* SRC_CAMION_HPP_ */
