/*
 * Concession.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include <Concession.hpp>
#include <ConcessionException.hpp>
#include "Vehicule.hpp"
#include "Moto.hpp"
#include <iostream>
#include <exception>
#include <typeinfo>

using namespace std;

Concession::Concession() :
	m_tresorerie(0), m_margin(0){
}

Concession::Concession(int tresorerieInitiale) :
	m_tresorerie(tresorerieInitiale){
	m_margin = 0.2;
}

Concession::~Concession() {
}

void Concession::ajouterNouveauVehicule(std::unique_ptr<Vehicule> pNouveauVehicule) {
	m_tableauPointerVehicules.push_back(move(pNouveauVehicule));
}

string Concession::inventaire(){
	string monInventaireDescription;
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;

	for (inventaireIt=m_tableauPointerVehicules.begin(); inventaireIt!=m_tableauPointerVehicules.end();inventaireIt++){
		monInventaireDescription+=(*inventaireIt)->description();
		monInventaireDescription+="\n";
	}
	return monInventaireDescription;
}

int Concession::calculerValeurStock(){
	int valeurStock(0);
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;

	for (inventaireIt=m_tableauPointerVehicules.begin(); inventaireIt!=m_tableauPointerVehicules.end();inventaireIt++){
		valeurStock+=(*inventaireIt)->getPrice();
	}
	return valeurStock;
}

int Concession::getTresorerie(){
	return m_tresorerie;
}

void Concession::updateTresorerie(int updateValue){
	m_tresorerie +=updateValue;
}

void Concession::removeVehicle(int indexVehiculeToDelete) {
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;

	inventaireIt = m_tableauPointerVehicules.begin() + indexVehiculeToDelete;
	m_tableauPointerVehicules.erase(inventaireIt);
}

void Concession::vendreVehicule(int indexVehiculeAvendre){
	if (this->isVehiculeIndexWithinRange(indexVehiculeAvendre)){
		updateTresorerie(m_tableauPointerVehicules[indexVehiculeAvendre]->getPrice());
		removeVehicle(indexVehiculeAvendre);
	}
	else
		throw(ConcessionException("Vehicle index outside range"));
}

bool Concession::isVehiculeIndexWithinRange(int indexVehiculeAvendre){
	return (indexVehiculeAvendre > 0 && indexVehiculeAvendre < (int)m_tableauPointerVehicules.size());
}

void Concession::acheter(std::unique_ptr<Vehicule> pNouveauVehicule)
{
	m_tresorerie-=(*pNouveauVehicule).getPrice()*(1-m_margin);
	ajouterNouveauVehicule(move(pNouveauVehicule));
}

double Concession::getMarge(){
	return m_margin;
}

int Concession::nombreVehicules(const char* vehicleType){
	int nbVehicules(0);
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;

	for (inventaireIt=m_tableauPointerVehicules.begin(); inventaireIt!=m_tableauPointerVehicules.end();inventaireIt++){
		if ((typeid(**inventaireIt).name()) == vehicleType)
			nbVehicules++;
	}
	return nbVehicules;
}

void Concession::reduction(int pourcentageReduction){
	if(100 < pourcentageReduction)
		throw ConcessionException("Reduction superieure � 100%");
	else
		applicationPourcentage(pourcentageReduction);
}

void Concession::applicationPourcentage(int pourcentage) {
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;
	int currentPrice(0);

	for (inventaireIt=m_tableauPointerVehicules.begin(); inventaireIt!=m_tableauPointerVehicules.end();inventaireIt++){
		currentPrice = (*inventaireIt)->getPrice();
		(*inventaireIt)->modifierPrix(currentPrice * (100 - pourcentage) / 100);
	}
}

void Concession::augmentation(int pourcentageAugmentation){
	applicationPourcentage(pourcentageAugmentation*-1);
}

void Concession::liquidationMarque(string marque){
	vector<std::unique_ptr<Vehicule>>::iterator inventaireIt;

	for (inventaireIt=m_tableauPointerVehicules.begin(); inventaireIt!=m_tableauPointerVehicules.end();inventaireIt++){
		if ((*inventaireIt)->getMarque() == marque)
			vendreVehicule(inventaireIt-m_tableauPointerVehicules.begin());
	}
}
