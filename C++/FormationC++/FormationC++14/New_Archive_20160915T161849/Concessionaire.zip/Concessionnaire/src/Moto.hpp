/*
 * Moto.hpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_MOTO_HPP_
#define SRC_MOTO_HPP_

#include "Vehicule.hpp"
#include <string>

class Moto : public Vehicule{
public:
	Moto(std::string marque, std::string modele, std::string couleur, int prix, int cylindree);
	virtual ~Moto();
	virtual std::string description() override;
private:
	int m_cylindree;
};

#endif /* SRC_MOTO_HPP_ */
