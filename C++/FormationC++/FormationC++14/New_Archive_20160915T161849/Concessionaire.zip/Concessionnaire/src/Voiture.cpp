/*
 * Voiture.cpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#include <Voiture.hpp>
#include <Vehicule.hpp>
#include <string>
using namespace std;

Voiture::Voiture(string marque, string modele, string couleur, string type, int prix) :
Vehicule(marque, modele, couleur, prix), m_type(type) {
}

Voiture::~Voiture() {
}

string Voiture::description(){
	string maDescription("");

	maDescription+=Vehicule::description()+" Type: "+ m_type;
	return maDescription;
}
