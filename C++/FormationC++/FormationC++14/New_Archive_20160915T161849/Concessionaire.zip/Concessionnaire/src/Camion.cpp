/*
 * Camion.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include <Camion.hpp>
#include <Vehicule.hpp>
#include <string>
using namespace std;

Camion::Camion(string marque, string modele, string couleur, int prix, int ptac) :
		Vehicule(marque, modele, couleur, prix), m_PTAC(ptac) {
}

Camion::~Camion() {
}

string Camion::description(){
	string maDescription("");

	maDescription+=Vehicule::description()+" PTAC: "+to_string(m_PTAC);
	return maDescription;
}
