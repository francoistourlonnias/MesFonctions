#include "Vehicule.hpp"
#include "Voiture.hpp"
#include "Moto.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <iostream>
#include <string>


class VehiculeClassTestFixture : public ::testing::Test {
protected:
     Vehicule maToyota;

public:
	 VehiculeClassTestFixture():maToyota("Toyota","Verso","Grey",22000){}
	~VehiculeClassTestFixture(){}
	void setUp(){}
	void tearDown(){}
};

TEST_F(VehiculeClassTestFixture, decrireVehicule){
EXPECT_EQ("Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000",maToyota.description());
}

TEST_F(VehiculeClassTestFixture, modifierPrix){

maToyota.modifierPrix(24000);
EXPECT_EQ("Marque: Toyota Modele: Verso Couleur: Grey Prix: 24000",maToyota.description());
}



