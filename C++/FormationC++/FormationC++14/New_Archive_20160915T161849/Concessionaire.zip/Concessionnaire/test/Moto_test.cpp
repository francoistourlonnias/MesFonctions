/*
 * test_Moto.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include "Vehicule.hpp"
#include "Voiture.hpp"
#include "Moto.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <iostream>
#include <string>

class MotoClassTestFixture : public ::testing::Test {
protected:
     Moto maDucati;

public:
	 MotoClassTestFixture():maDucati("Ducati","Thunder","Red",13000,900){}
	~MotoClassTestFixture(){}
	void setUp(){}
	void tearDown(){}
};

class VoitureClassTestFixture : public ::testing::Test {
protected:
     Voiture maPunto;

public:
	 VoitureClassTestFixture():maPunto("Fiat","Punto","White","Citadine",2000){}
	~VoitureClassTestFixture(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(MotoClassTestFixture, decrireMoto){
EXPECT_EQ("Marque: Ducati Modele: Thunder Couleur: Red Prix: 13000 Cylindree: 900",maDucati.description());
}


