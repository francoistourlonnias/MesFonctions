/*
 * test_Voiture.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include "Vehicule.hpp"
#include "Voiture.hpp"
#include "Moto.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <iostream>
#include <string>


class VoitureClassTestFixture : public ::testing::Test {
protected:
     Voiture maPunto;

public:
	 VoitureClassTestFixture():maPunto("Fiat","Punto","White","Citadine",2000){}
	~VoitureClassTestFixture(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(VoitureClassTestFixture, decrireVoiture){
EXPECT_EQ("Marque: Fiat Modele: Punto Couleur: White Prix: 2000 Type: Citadine",maPunto.description());
}
