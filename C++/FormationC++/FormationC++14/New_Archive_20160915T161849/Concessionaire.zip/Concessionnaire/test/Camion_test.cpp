/*
 * Camion_test.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include "Vehicule.hpp"
#include "Voiture.hpp"
#include "Camion.hpp"
#include "Moto.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <iostream>
#include <string>

class CamionClassTestFixture : public ::testing::Test {
protected:
     Camion monCamion;

public:
	 CamionClassTestFixture():monCamion("Man","450v","Yellow",102000,23){}
	~CamionClassTestFixture(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(CamionClassTestFixture, decrireCamion){
EXPECT_EQ("Marque: Man Modele: 450v Couleur: Yellow Prix: 102000 PTAC: 23",monCamion.description());
}
