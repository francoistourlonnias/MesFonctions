/*
 * Concession_test.cpp
 *
 *  Created on: 23 juil. 2016
 *      Author: mmeinero
 */

#include <Concession.hpp>
#include "Vehicule.hpp"
#include "Voiture.hpp"
#include "Moto.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include <iostream>
#include <string>
#include <memory>
#include <exception>
#include <ConcessionException.hpp>
#include "Camion.hpp"
using namespace std;

class ConcessionClassTestFixtureSansVente : public ::testing::Test {
protected:
     Concession maConcession;

public:
	 ConcessionClassTestFixtureSansVente():maConcession(){
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Vehicule> pMaPunto(new Vehicule("FIAT","Punto","Black",3000));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
	 }
	~ConcessionClassTestFixtureSansVente(){}
	void setUp(){}
	void tearDown(){}
};

TEST_F(ConcessionClassTestFixtureSansVente, inventaireEstLaDescriptionDeTousLesVehicules){
EXPECT_EQ(
"Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000 Type: Familiale\n\
Marque: FIAT Modele: Punto Couleur: Black Prix: 3000\n\
Marque: Kawasaki Modele: Tiger Couleur: Blue Prix: 12000 Cylindree: 1100\n",
maConcession.inventaire());
}

TEST_F(ConcessionClassTestFixtureSansVente, valeurStockEstLaSommeDesPrixDeTousLesVehicules){
EXPECT_EQ(37000,maConcession.calculerValeurStock());
}

TEST_F(ConcessionClassTestFixtureSansVente, valeurTresorerieEstNulleSiConstructeurParDefaut){
EXPECT_EQ(0,maConcession.getTresorerie());
}


class ConcessionClassTestFixtureAvecVente : public ::testing::Test {
protected:
     Concession maConcession;

public:
	 ConcessionClassTestFixtureAvecVente():maConcession(10000){
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Vehicule> pMaPunto(new Vehicule("FIAT","Punto","Black",3000));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
	 }
	~ConcessionClassTestFixtureAvecVente(){}
	void setUp(){}
	void tearDown(){}
};

TEST_F(ConcessionClassTestFixtureAvecVente, laTresorerieCorrespondALaValeurPasseeAuConstructeur){
EXPECT_EQ(10000,maConcession.getTresorerie());
}

TEST_F(ConcessionClassTestFixtureAvecVente, apresUneVenteLaTresorerieAugmenteDuPrixDuVehiculeVendu){
	maConcession.vendreVehicule(1);
EXPECT_EQ(13000,maConcession.getTresorerie());
}

TEST_F(ConcessionClassTestFixtureAvecVente, apresUneVenteLInventaireNeContientPlusLaDescriptionDuVehiculeVendu){

	maConcession.vendreVehicule(1);
EXPECT_EQ(
"Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000 Type: Familiale\n\
Marque: Kawasaki Modele: Tiger Couleur: Blue Prix: 12000 Cylindree: 1100\n",
maConcession.inventaire());
}


TEST_F(ConcessionClassTestFixtureAvecVente, siOnEssayeDeVendreUnVehiculeHorsRangeOnObtientUneException){

	EXPECT_ANY_THROW(maConcession.vendreVehicule(3));
}

class ConcessionClassTestFixtureAchat : public ::testing::Test {
protected:
     Concession maConcession;
     std::unique_ptr<Camion> pNouveauCamion;

public:
	 ConcessionClassTestFixtureAchat():
		 maConcession(10000),
		 pNouveauCamion(new Camion("Iveco","440s","Green",98000,76))

{
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Vehicule> pMaPunto(new Vehicule("FIAT","Punto","Black",3000));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
	 }
	~ConcessionClassTestFixtureAchat(){}
	void setUp(){}
	void tearDown(){}
};

TEST_F(ConcessionClassTestFixtureAchat, laMethodePourAcheterUnVehiculeEstDisponible){

	maConcession.acheter(move(pNouveauCamion));

}

TEST_F(ConcessionClassTestFixtureAchat, apresUnAchatLInventaireContientLaDescriptionDuVehiculeAchete){

	maConcession.acheter(move(pNouveauCamion));

EXPECT_EQ(
"Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000 Type: Familiale\n\
Marque: FIAT Modele: Punto Couleur: Black Prix: 3000\n\
Marque: Kawasaki Modele: Tiger Couleur: Blue Prix: 12000 Cylindree: 1100\n\
Marque: Iveco Modele: 440s Couleur: Green Prix: 98000 PTAC: 76\n",
	maConcession.inventaire());

}

TEST_F(ConcessionClassTestFixtureAchat, apresUnAchatLaTresorieFinaleEstDiminueDuPrixBrutMoinsMarge){

	int tresorerieInitiale = maConcession.getTresorerie();
	int prixVehicule = pNouveauCamion->getPrice();
	double margin = maConcession.getMarge();
	maConcession.acheter(move(pNouveauCamion));
	int tresorerieFinale = maConcession.getTresorerie();

EXPECT_EQ(tresorerieInitiale-(1-margin)*prixVehicule,tresorerieFinale);

}


class ConcessionClassTestFixtureNombreVehicules : public ::testing::Test {
protected:
     Concession maConcession;
     std::unique_ptr<Camion> pNouveauCamion;

public:
	 ConcessionClassTestFixtureNombreVehicules():
		 maConcession(10000),
		 pNouveauCamion(new Camion("Iveco","440s","Green",98000,76))

{
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Vehicule> pMaPunto(new Voiture("FIAT","Punto","Black","Epave",3000));
		 std::unique_ptr<Vehicule> pMaRenault(new Voiture("Renault","Scenic","Purple","En pannes",23000));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 std::unique_ptr<Moto> pMaDucati(new Moto("Ducati","Monster","Black",14000,900));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaRenault));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
		 maConcession.ajouterNouveauVehicule(move(pMaDucati));
		 maConcession.acheter(move(pNouveauCamion));
	 }
	~ConcessionClassTestFixtureNombreVehicules(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(ConcessionClassTestFixtureNombreVehicules, laConcessionPeutDeterminerLeNombreDeMotos){

EXPECT_EQ(2,maConcession.nombreVehicules(typeid(Moto).name()));
}

TEST_F(ConcessionClassTestFixtureNombreVehicules, laConcessionPeutDeterminerLeNombreDeVoitures){

EXPECT_EQ(3,maConcession.nombreVehicules(typeid(Voiture).name()));
}

TEST_F(ConcessionClassTestFixtureNombreVehicules, laConcessionPeutDeterminerLeNombreDeCamions){

EXPECT_EQ(1,maConcession.nombreVehicules(typeid(Camion).name()));
}


class ConcessionClassTestFixtureReductionAugmentation : public ::testing::Test {
protected:
     Concession maConcession;
     std::unique_ptr<Camion> pNouveauCamion;

public:
     ConcessionClassTestFixtureReductionAugmentation():
		 maConcession(10000),
		 pNouveauCamion(new Camion("Iveco","440s","Green",98000,76))

{
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Vehicule> pMaPunto(new Voiture("FIAT","Punto","Black","Epave",3000));
		 std::unique_ptr<Vehicule> pMaRenault(new Voiture("Renault","Scenic","Purple","En pannes",23000));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 std::unique_ptr<Moto> pMaDucati(new Moto("Ducati","Monster","Black",14000,900));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaRenault));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
		 maConcession.ajouterNouveauVehicule(move(pMaDucati));
		 maConcession.acheter(move(pNouveauCamion));
	 }
	~ConcessionClassTestFixtureReductionAugmentation(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(ConcessionClassTestFixtureReductionAugmentation, onPeutReduireLePrixDeTousLesVehiculeDunPourcentage){
	maConcession.reduction(20);
}

TEST_F(ConcessionClassTestFixtureReductionAugmentation, exceptionSiLaReductionDepasse100pourcent){

	EXPECT_ANY_THROW(maConcession.reduction(110));
}

TEST_F(ConcessionClassTestFixtureReductionAugmentation, apresReductionDePrixLaValeurDuStockEstDiminueDuMemePourcentage){
	int valeurStock(0);
	int nouvelleValeurStock(0);
	int reduction(10);

	valeurStock=maConcession.calculerValeurStock();
	maConcession.reduction(reduction);
	nouvelleValeurStock=maConcession.calculerValeurStock();
	EXPECT_EQ(valeurStock*(100-reduction)/100,nouvelleValeurStock);
}

TEST_F(ConcessionClassTestFixtureReductionAugmentation, onPeutAugementerLePrixDeTousLesVehiculeDunPourcentage){
	maConcession.augmentation(10);
}

TEST_F(ConcessionClassTestFixtureReductionAugmentation, apresAugmentationDePrixLaValeurDuStockEstAugmenteeDuMemePourcentage){
	int valeurStock(0);
	int nouvelleValeurStock(0);
	int augmentation(20);

	valeurStock=maConcession.calculerValeurStock();
	maConcession.augmentation(augmentation);
	nouvelleValeurStock=maConcession.calculerValeurStock();
	EXPECT_EQ(valeurStock*(100+augmentation)/100,nouvelleValeurStock);
}


class ConcessionClassTestFixtureLiquidationMarque : public ::testing::Test {
protected:
     Concession maConcession;

public:
     ConcessionClassTestFixtureLiquidationMarque():
		 maConcession(10000)
{
		 std::unique_ptr<Voiture> pMaToyota(new Voiture("Toyota","Verso","Grey","Familiale",22000));
		 std::unique_ptr<Voiture> pMaPunto(new Voiture("FIAT","Punto","Black","Epave",3000));
		 std::unique_ptr<Voiture> pMaRenault(new Voiture("Renault","Scenic","Purple","En pannes",23000));
		 std::unique_ptr<Moto> pMaDucati(new Moto("Ducati","Monster","Black",14000,900));
		 std::unique_ptr<Voiture> pMaCinquecento(new Voiture("FIAT","Cinquecento","White","Citadine",12000));
		 std::unique_ptr<Camion> pNouveauCamion(new Camion("Iveco","440s","Green",98000,76));
		 std::unique_ptr<Moto> pMaKawasaki(new Moto("Kawasaki","Tiger","Blue",12000,1100));
		 maConcession.ajouterNouveauVehicule(move(pMaToyota));
		 maConcession.ajouterNouveauVehicule(move(pMaPunto));
		 maConcession.ajouterNouveauVehicule(move(pMaRenault));
		 maConcession.ajouterNouveauVehicule(move(pMaDucati));
		 maConcession.ajouterNouveauVehicule(move(pMaCinquecento));
		 maConcession.ajouterNouveauVehicule(move(pNouveauCamion));
		 maConcession.ajouterNouveauVehicule(move(pMaKawasaki));
	 }
	~ConcessionClassTestFixtureLiquidationMarque(){}
	void setUp(){}
	void tearDown(){}
};


TEST_F(ConcessionClassTestFixtureLiquidationMarque , onPeutLiquiderUneMarque){
	maConcession.liquidationMarque("FIAT");
}

TEST_F(ConcessionClassTestFixtureLiquidationMarque, apresLiquidationLInventaireNeContientPlusLesVehiculesDeLaMarque){

EXPECT_EQ(
"Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000 Type: Familiale\n\
Marque: FIAT Modele: Punto Couleur: Black Prix: 3000 Type: Epave\n\
Marque: Renault Modele: Scenic Couleur: Purple Prix: 23000 Type: En pannes\n\
Marque: Ducati Modele: Monster Couleur: Black Prix: 14000 Cylindree: 900\n\
Marque: FIAT Modele: Cinquecento Couleur: White Prix: 12000 Type: Citadine\n\
Marque: Iveco Modele: 440s Couleur: Green Prix: 98000 PTAC: 76\n\
Marque: Kawasaki Modele: Tiger Couleur: Blue Prix: 12000 Cylindree: 1100\n",
maConcession.inventaire());

maConcession.liquidationMarque("FIAT");

EXPECT_EQ(
"Marque: Toyota Modele: Verso Couleur: Grey Prix: 22000 Type: Familiale\n\
Marque: Renault Modele: Scenic Couleur: Purple Prix: 23000 Type: En pannes\n\
Marque: Ducati Modele: Monster Couleur: Black Prix: 14000 Cylindree: 900\n\
Marque: Iveco Modele: 440s Couleur: Green Prix: 98000 PTAC: 76\n\
Marque: Kawasaki Modele: Tiger Couleur: Blue Prix: 12000 Cylindree: 1100\n",
maConcession.inventaire());

}

TEST_F(ConcessionClassTestFixtureLiquidationMarque, apresLiquidationLaValeurStockEstDiminueeDeLaValeurDesVehiculesVendus){

int valeurStockInitiale = maConcession.calculerValeurStock();
int prixDucati = 14000;

maConcession.liquidationMarque("Ducati");

EXPECT_EQ(valeurStockInitiale-prixDucati,maConcession.calculerValeurStock());

}
