#include "Duree.hpp"
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <memory>

using namespace std;

int main()
{
	Duree parisLyon(2,13,13);
	Duree lyonTurin(3,18,12);
	Duree parisLondres(2,33,23);


	cout << "**************** Vector ***************" << endl;
	vector<Duree> dureeTrajets;
	vector<Duree>::iterator dureeTrajetsIt;

	dureeTrajets.push_back(parisLyon);
	dureeTrajets.push_back(lyonTurin);
	dureeTrajets.push_back(parisLondres);

	for (dureeTrajetsIt=dureeTrajets.begin(); dureeTrajetsIt!=dureeTrajets.end();dureeTrajetsIt++)
	{
		cout << (*dureeTrajetsIt).affiche();
	}

	cout << "**************** Map ***************" << endl;
	map<string, Duree> trajets;
	trajets.insert(pair<string,Duree>("Paris Lyon",parisLyon));
	trajets.insert(pair<string,Duree>("Lyon Turin",lyonTurin));
	trajets.insert(pair<string,Duree>("Paris Londres",parisLondres));

	map<string, Duree>::iterator trajetsIt;

	for (trajetsIt=trajets.begin();trajetsIt!=trajets.end();trajetsIt++)
	{
		cout << (*trajetsIt).first << " " << (*trajetsIt).second.affiche();
	}
	cout << endl;


	cout << "**************** Sort of Vector with functor*******" << endl;

	class compareDuree{
	public:
		bool operator() (Duree d1, Duree d2)
		{
			return !(d1<d2);
		}
	};

	sort(dureeTrajets.begin(),dureeTrajets.end(),compareDuree());

	for (trajetsIt=trajets.begin();trajetsIt!=trajets.end();trajetsIt++)
	{
		cout << (*trajetsIt).first << " " << (*trajetsIt).second.affiche();
	}
	cout << endl;


	cout << "**************** Map print with auto + interval for ***************" << endl;

	for(auto curseur:trajets)
	{
		cout << curseur.first << " " << curseur.second.affiche();
	}

	cout << "**************** Sort of Vector with lambda *******" << endl;

	auto lambdaCompare = [](auto d1, auto d2){return (d1<d2);};

	sort(dureeTrajets.begin(),dureeTrajets.end(),lambdaCompare);

	for (auto curseur:dureeTrajets)
	{
		cout << curseur.affiche();
	}

	cout << "********************** Move Semantic ***********************" << endl;

	std::unique_ptr<Duree> ptDuree(new Duree(2,3,4));
	std::unique_ptr<Duree> ptDuree2 = move(ptDuree);

	cout << ptDuree2->affiche() << endl;
	//cout << ptDuree->affiche() << endl; // this code compiles but raises an exception

}
