/*
 * Fauve.h
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#ifndef FAUVE_HPP_
#define FAUVE_HPP_

#include "Felin.hpp"
#include <string>

class Fauve: public Felin {
public:
	Fauve(std::string nom, std::string espece, int age, std::string proiePreferee);
	Fauve(std::string nom, std::string espece, int age, std::string proiePreferee, std::string proieDuJour);
	virtual ~Fauve();
	std::string seNourrir() override;
	std::string sePresenter() override;
private:
	std::string m_proiePreferee;
	std::string m_proieDuJour;
};

#endif /* FAUVE_HPP_ */
