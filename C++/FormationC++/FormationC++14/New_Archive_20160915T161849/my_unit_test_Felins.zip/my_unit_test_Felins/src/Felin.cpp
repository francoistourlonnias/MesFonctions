/*
 * Felin.cpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#include "Felin.hpp"
#include <string>

using namespace std;

Felin::Felin(string nom, string espece, int age):
	m_nom(nom),m_espece(espece),m_age(5)
{
	// TODO Auto-generated constructor stub
}

Felin::~Felin() {
	// TODO Auto-generated destructor stub
}

string Felin::seNourrir()
{
	string ceQueJeMange("");

	ceQueJeMange += "\nJe mange";
	return ceQueJeMange;
}

string Felin::sePresenter()
{
	string jeMePresente("\nBonjour, ");

	jeMePresente+= "je suis ";
	jeMePresente+= m_nom + ", ";
	jeMePresente+= "j'ai " + to_string(m_age) + " ans, ";
	jeMePresente+= "je suis un " + m_espece;
	return jeMePresente;
}
