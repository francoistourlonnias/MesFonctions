/*
 * Hello.cpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#include <Hello.hpp>
#include <iostream>

using namespace std;


Hello::Hello() {
	// TODO Auto-generated constructor stub

}

Hello::~Hello() {
	// TODO Auto-generated destructor stub
}

string Hello::sayHello()
{
	return "Hello World";
}


