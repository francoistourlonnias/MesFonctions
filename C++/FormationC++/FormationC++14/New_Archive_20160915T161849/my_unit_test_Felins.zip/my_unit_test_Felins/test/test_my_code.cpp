//test_factorial.cpp

#include "hello.hpp"
#include "ChatDomestique.hpp"
#include "Felin.hpp"
#include "gtest/gtest.h"
#include "gmock/gmock.h"

class HelloClassTest : public ::testing::Test {
protected:
	Hello myHello;
};

TEST_F(HelloClassTest, myHello) {
	EXPECT_EQ("Hello World",myHello.sayHello());
}

class ChatDomestiqueFixture : public ::testing::Test {
protected:

	ChatDomestique* m_chatDomestique;

public:
	ChatDomestiqueFixture(){
		m_chatDomestique = new ChatDomestique("Felix","vert");
	}

	~ChatDomestiqueFixture(){
		delete m_chatDomestique;
	}

	void setUp(){
	}

	void tearDown(){
	}
};

TEST_F(ChatDomestiqueFixture, testChatDomestique) {
	EXPECT_EQ("\nJe mange des croquettes",m_chatDomestique->seNourrir());
}

