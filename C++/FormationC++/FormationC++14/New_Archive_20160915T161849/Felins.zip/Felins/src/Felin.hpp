/*
 * Felin.hpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#ifndef FELIN_HPP_
#define FELIN_HPP_

#include <iostream>
#include <string>

class Felin {
public:
	Felin(std::string nom, std::string espece, int age);
	virtual ~Felin();

	virtual std::string seNourrir()=0;
	virtual std::string sePresenter()=0;
protected:
	std::string m_nom;
	std::string m_espece;
	int m_age;
};

#endif /* FELIN_HPP_ */
