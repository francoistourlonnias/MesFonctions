/*
 * Fauve.cpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#include "Fauve.hpp"
#include <string>
using namespace std;

Fauve::Fauve(string nom, string espece, int age, string proiePreferee):
				Felin(nom,espece,age), m_proiePreferee(proiePreferee), m_proieDuJour(proiePreferee)
{
	// TODO Auto-generated constructor stub

}

Fauve::Fauve(string nom, string espece, int age, string proiePreferee, string proieDuJour):
				Felin(nom,espece,age), m_proiePreferee(proiePreferee), m_proieDuJour(proieDuJour)
{
	// TODO Auto-generated constructor stub

}


Fauve::~Fauve() {
	// TODO Auto-generated destructor stub
}

string Fauve::sePresenter()
{
	string jeMePresente("");
	jeMePresente+=Felin::sePresenter();
	jeMePresente+=", ma proie prefer�e est le " + m_proiePreferee;
	return jeMePresente;
}

string Fauve::seNourrir()
{
	string jeMange("");

	jeMange+=Felin::seNourrir()+ " un " + m_proieDuJour;
	return jeMange;
}
