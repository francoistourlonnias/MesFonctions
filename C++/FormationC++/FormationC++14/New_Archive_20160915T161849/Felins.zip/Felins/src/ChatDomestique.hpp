/*
 * ChatDomestique.h
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#ifndef CHATDOMESTIQUE_HPP_
#define CHATDOMESTIQUE_HPP_

#include "Felin.hpp"
#include <string>

class ChatDomestique: public Felin {
public:
	ChatDomestique(std::string nom, std::string espece, int age, std::string couleurCollier);
	ChatDomestique(std::string nom, std::string couleurCollier);
	ChatDomestique(std::string nom, std::string espece, std::string couleurCollier);
	virtual ~ChatDomestique();
	std::string sePresenter() override;
	std::string seNourrir();
private:
	std::string m_couleurCollier;
	std::string m_nourriture;
};

#endif /* CHATDOMESTIQUE_HPP_ */
