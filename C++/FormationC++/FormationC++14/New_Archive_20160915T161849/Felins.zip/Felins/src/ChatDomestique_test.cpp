/*
 * ChatDomestique_test.cpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#include "ChatDomestique.hpp"

