/*
 * ChatDomestique.cpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#include "ChatDomestique.hpp"
#include <string>
using namespace std;

ChatDomestique::ChatDomestique(string nom, string espece, int age, string couleurCollier):
Felin(nom,espece,age), m_couleurCollier(couleurCollier), m_nourriture("croquettes")
{
	// TODO Auto-generated constructor stub

}

ChatDomestique::ChatDomestique(string nom, string couleurCollier):
Felin(nom,"croisement",0), m_couleurCollier(couleurCollier), m_nourriture("croquettes")
{
	// TODO Auto-generated constructor stub

}

ChatDomestique::ChatDomestique(string nom, string espece, string couleurCollier):
Felin(nom,espece,0), m_couleurCollier(couleurCollier), m_nourriture("croquettes")
{
	// TODO Auto-generated constructor stub

}


ChatDomestique::~ChatDomestique() {
	// TODO Auto-generated destructor stub
}

string ChatDomestique::sePresenter()
{
	string jeMePresente("");
	jeMePresente+=Felin::sePresenter();
	jeMePresente+=", mon collier est " + m_couleurCollier;
	return jeMePresente;
}

string ChatDomestique::seNourrir()
{
	string jeMange("");

	jeMange+=Felin::seNourrir()+ " des " + m_nourriture;

	return jeMange;
}
