//============================================================================
// Name        : Felins.cpp
// Author      : Marco Meinero
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

#include "ChatDomestique.hpp"
#include "Felin.hpp"
#include "Fauve.hpp"
using namespace std;

int main() {

	//Felin felin("F�lix","f�lin",5);
	ChatDomestique chatTom("Tom","chat",4, "rouge");
	ChatDomestique chatSylvester("Sylvester","vert");
	Fauve unLion("Roar","lion",5,"gnu");
	Fauve unTigre("Yellow beast","tigre",3,"sanglier","cerf");

	const int nombreFelins(4);

	Felin* tableauFelins[nombreFelins]={&chatTom,&unLion,&chatSylvester,&unTigre};


	//cout << felin.seNourrir();
	//cout << felin.sePresenter();
	cout << chatTom.sePresenter();
	cout << chatTom.seNourrir();
	cout << chatSylvester.sePresenter();
	cout << chatSylvester.seNourrir();
	cout << unLion.sePresenter();
	cout << unLion.seNourrir();
	cout << unTigre.sePresenter();
	cout << unTigre.seNourrir();
	cout << endl;

	for (int i=0; i< nombreFelins; i++)
	{
		cout <<tableauFelins[i]->sePresenter();
		cout <<tableauFelins[i]->seNourrir();
		cout << endl;
	}

	return 0;
}
