/*
 * TrainStation.cpp
 *
 *  Created on: 21 juil. 2016
 *      Author: mmeinero
 */

#include <ITrainDatabase.hpp>
#include <TrainStation.hpp>
#include <TrainDataBase.hpp>
#include <string>

using namespace std;

TrainStation::TrainStation(ITrainDatabase* pITrainDatabase)
:m_pITrainDatabase(pITrainDatabase)
 {
	// TODO Auto-generated constructor stub

}

TrainStation::~TrainStation() {
	// TODO Auto-generated destructor stub
}


Duree TrainStation::getDureeTrajet(string nomDuTrajet)
{
	return m_pITrainDatabase->getTrajetDuration(nomDuTrajet);
}

Duree TrainStation::getDureeTrajet(string nomDuTrajet, Duree retard)
{
	return m_pITrainDatabase->getTrajetDuration(nomDuTrajet) + retard;
}

