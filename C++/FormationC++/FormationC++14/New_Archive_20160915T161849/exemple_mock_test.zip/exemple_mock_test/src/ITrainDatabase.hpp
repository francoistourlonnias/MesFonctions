/*
 * iTraindDatabase.hpp
 *
 *  Created on: 22 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_ITRAINDATABASE_HPP_
#define SRC_ITRAINDATABASE_HPP_

#include "Duree.hpp"
#include <vector>
#include <string>
#include <vector>
#include <map>

using namespace std;

class ITrainDatabase {
public:
	ITrainDatabase(){};
	virtual ~ITrainDatabase(){};

	virtual Duree getTrajetDuration(std::string nomTrajet)=0;
};

#endif /* SRC_ITRAINDATABASE_HPP_ */
