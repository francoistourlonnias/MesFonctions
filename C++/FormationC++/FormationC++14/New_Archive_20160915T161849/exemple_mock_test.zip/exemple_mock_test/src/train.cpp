///*
// * Hello.cpp
// *
// *  Created on: 19 juil. 2016
// *      Author: mmeinero
// */
//
//#include <train.hpp>
//#include <iostream>
//#include "TrainDatabase.hpp"
//
//using namespace std;
//
//
//Hello::Hello() {
//	// TODO Auto-generated constructor stub
//
//}
//
//Hello::~Hello() {
//	// TODO Auto-generated destructor stub
//}
//
//string Hello::sayHello()
//{
//	TrainDatabase myTrainDatabase;
//
//	Duree parisLyon(2,13,13);
//	Duree lyonTurin(3,18,12);
//	Duree parisLondres(2,33,23);
//
//	map<string, Duree> trajets;
//	trajets.insert(pair<string,Duree>("Paris Lyon",parisLyon));
//	trajets.insert(pair<string,Duree>("Lyon Turin",lyonTurin));
//	trajets.insert(pair<string,Duree>("Paris Londres",parisLondres));
//
//	for(auto curseur:trajets)
//	{
//		myTrainDatabase.populateTrainDatabase(curseur.first,curseur.second);
//	}
//
//	return "Hello World";
//
//}
//
//
