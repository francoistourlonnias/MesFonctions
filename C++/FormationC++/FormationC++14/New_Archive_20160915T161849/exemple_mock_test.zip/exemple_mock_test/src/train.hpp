/*
 * Hello.hpp
 *
 *  Created on: 19 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_TRAIN_HPP_
#define SRC_TRAIN_HPP_

#include <string>

class Hello {
public:
	Hello();
	virtual ~Hello();

	std::string sayHello();
};

#endif /* SRC_TRAIN_HPP_ */
