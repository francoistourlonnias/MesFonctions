/*
 * TrainStation.hpp
 *
 *  Created on: 21 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_TRAINSTATION_HPP_
#define SRC_TRAINSTATION_HPP_

#include "TrainDatabase.hpp"
#include "Duree.hpp"

using namespace std;

class TrainStation {
public:
	TrainStation(ITrainDatabase *pITrainDatabase);
	virtual ~TrainStation();

	Duree getDureeTrajet(string nomDuTrajet);
	Duree getDureeTrajet(string nomDuTrajet, Duree retard);

private:
	ITrainDatabase* m_pITrainDatabase;
};


#endif /* SRC_TRAINSTATION_HPP_ */
