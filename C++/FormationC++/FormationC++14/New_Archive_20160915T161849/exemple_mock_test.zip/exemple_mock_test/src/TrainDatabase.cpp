/*
 * TrainDatabase.cpp
 *
 *  Created on: 21 juil. 2016
 *      Author: mmeinero
 */

#include <ITrainDatabase.hpp>
#include <TrainDatabase.hpp>

using namespace std;

TrainDatabase::TrainDatabase() {
	// TODO Auto-generated constructor stub

}

TrainDatabase::~TrainDatabase() {
	// TODO Auto-generated destructor stub
}

void TrainDatabase::populateTrainDatabase(std::string descriptionTrajet, Duree dureeTrajet){

	m_TrajetDatabase.insert(pair<string,Duree>(descriptionTrajet,dureeTrajet));

	//dureeTrajets.push_back(trajet);
}

Duree TrainDatabase::getTrajetDuration(std::string nomTrajet)
{
	return (*m_TrajetDatabase.find(nomTrajet)).second;
}

