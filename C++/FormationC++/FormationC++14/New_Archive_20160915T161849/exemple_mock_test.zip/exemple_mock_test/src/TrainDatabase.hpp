/*
 * TrainDatabase.hpp
 *
 *  Created on: 21 juil. 2016
 *      Author: mmeinero
 */

#ifndef SRC_TRAINDATABASE_HPP_
#define SRC_TRAINDATABASE_HPP_

#include <ITrainDatabase.hpp>
#include <vector>
#include <string>
#include <vector>
#include <map>
#include "Duree.hpp"

using namespace std;

class TrainDatabase : public ITrainDatabase{
public:
	TrainDatabase();
	virtual ~TrainDatabase();

	void populateTrainDatabase(std::string descriptionTrajet, Duree dureeTrajet);
	Duree getTrajetDuration(std::string nomTrajet);

private:
	map<string, Duree> m_TrajetDatabase;
	vector<Duree> dureeTrajets;
};


#endif /* SRC_TRAINDATABASE_HPP_ */
