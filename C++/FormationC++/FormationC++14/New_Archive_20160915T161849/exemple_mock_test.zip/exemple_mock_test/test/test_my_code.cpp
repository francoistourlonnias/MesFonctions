//test_factorial.cpp

#include <ITrainDatabase.hpp>
#include <train.hpp>
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include "TrainStation.hpp"
#include "TrainDatabase.hpp"
#include "Duree.hpp"

using ::testing ::Return;
Duree parisLyon(2,13,13);
Duree retard(1,1,1);

class TrainDatabaseMock : public ITrainDatabase{

public:
	MOCK_METHOD1(getTrajetDuration,Duree(std::string nomTrajet));

};


TEST(TestTrainStation, testThatGetTrajetDurationReturnsDuration){
	TrainDatabaseMock myDatabaseMock;
	TrainStation myTrainStation(&myDatabaseMock);

	Duree parisLyonComputed(0,0,0);

EXPECT_CALL(myDatabaseMock,getTrajetDuration("Paris Londres"))
	.WillOnce(Return(parisLyon));

	parisLyonComputed=myTrainStation.getDureeTrajet("Paris Londres");

EXPECT_EQ(parisLyon, parisLyonComputed);

}


TEST(TestTrainStation, testThatGetTrajetDurationReturnsDurationWithDelay){
	TrainDatabaseMock myDatabaseMock;
	TrainStation myTrainStation(&myDatabaseMock);
	Duree parisLyonAvecRetard(0,0,0);
	Duree parisLyonAvecRetardComputed(0,0,0);

	parisLyonAvecRetard = parisLyon + retard;

EXPECT_CALL(myDatabaseMock,getTrajetDuration("Paris Londres"))
	.WillOnce(Return(parisLyon));

	parisLyonAvecRetardComputed = myTrainStation.getDureeTrajet("Paris Londres", retard);

EXPECT_EQ(parisLyonAvecRetard, parisLyonAvecRetardComputed);

}

