/*
 * ApartmentException.cpp
 *
 *  Created on: 20 juil. 2016
 *      Author: mmeinero
 */

#include "ApartmentException.hpp"

namespace std {

ApartmentException::ApartmentException(string errorMessage) :
m_errorMessage(errorMessage)
{
	// TODO Auto-generated constructor stub

}

ApartmentException::~ApartmentException() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
