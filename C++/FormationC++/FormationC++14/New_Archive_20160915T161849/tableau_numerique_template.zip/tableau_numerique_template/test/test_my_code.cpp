//test_factorial.cpp

#include "gtest/gtest.h"
#include "findMaxTemplateFunction.hpp"


int intArray[5]={7,3,9,17,12};
int intAnotherArray[7]={7,3,9,5,12,8,9};
double doubleArray[5]={1.2,1.6,3.7,1.3,0.2};


TEST(TableauNumeriqueBasicTest, findMaxValueInIntArrayWithoutTemplate) {
	EXPECT_EQ(17,findMaxValueInArray(intArray,5));
}

TEST(TableauNumeriqueBasicTest, findMaxValueInIntArrayWithTemplate) {
	EXPECT_EQ(17,felixibleFindMaxValueInArray(intArray,5));
	EXPECT_EQ(12,felixibleFindMaxValueInArray(intAnotherArray,5));
}

TEST(TableauNumeriqueBasicTest, findMaxValueInDoubleArrayWithTemplate) {
	EXPECT_EQ(3.7,felixibleFindMaxValueInArray(doubleArray,5));
}

