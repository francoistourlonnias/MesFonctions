/*
 * findMaxTemplateFunction.cpp
 *
 *  Created on: 20 juil. 2016
 *      Author: mmeinero
 */

#include "findMaxTemplateFunction.hpp"

int findMaxValueInArray(int* array, int size)
{
	int tmpMax=array[0];

	for (int i=0; i<size;i++)
	{
		if(array[i] > tmpMax)
		{
			tmpMax = array[i];
		}
	}
	return tmpMax;
}

