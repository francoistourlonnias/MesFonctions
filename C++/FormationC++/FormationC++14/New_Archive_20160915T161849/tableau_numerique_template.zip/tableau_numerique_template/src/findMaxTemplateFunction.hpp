/*
 * findMaxTemplateFunction.hpp
 *
 *  Created on: 20 juil. 2016
 *      Author: mmeinero
 */

#ifndef FINDMAXTEMPLATEFUNCTION_HPP_
#define FINDMAXTEMPLATEFUNCTION_HPP_

int findMaxValueInArray(int* array, int size);

template<typename T>
T felixibleFindMaxValueInArray(T* array, int size)
{
	T tmpMax=array[0];

	for (int i=0; i<size;i++)
	{
		if(array[i] > tmpMax)
		{
			tmpMax = array[i];
		}
	}
	return tmpMax;
}


#endif /* FINDMAXTEMPLATEFUNCTION_HPP_ */
